using HarmonyLib;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewModdingAPI;
using StardewValley;

namespace FarmerTallFit
{
    public class ModEntry : Mod
    {
        // Tambahan tinggi sprite (piksel). Kepala/rambut/topi naik sebanyak ini.
        public const int ExtraHeight = 2;

        public override void Entry(IModHelper helper)
        {
            var harmony = new Harmony(this.ModManifest.UniqueID);
            harmony.Patch(
                original: AccessTools.Method(typeof(FarmerRenderer), "drawHairAndAccesories"),
                prefix: new HarmonyMethod(typeof(ModEntry), nameof(DrawHair_Prefix))
            );
        }

        // Geser rambut, topi, dan aksesori ke atas sebesar ExtraHeight piksel (dikali scale).
        private static void DrawHair_Prefix(ref Vector2 position, float scale)
        {
            position.Y -= ExtraHeight * scale;
        }
    }
}
